import { Module } from '@nestjs/common'
import { PrismaModule } from '../../prisma/prisma.module'
import { ActiveStoreModule } from '../active-store.module'
import { CryptoModule } from '../../common/crypto/crypto.module'
import { IdsModule } from '../../common/ids/ids.module'
import { LedgerModule } from '../../ledger/ledger.module'
import { MessagingModule } from '../../common/messaging/messaging.module'
import { GatewaysModule } from './gateways/gateways.module'
import { PaymentAccountService } from './payment-account.service'
import { PaymentSettingsController } from './payment-settings.controller'
import { PaymentCollectionService } from './payment-collection.service'
import { PaymentQueryService } from './payment-query.service'
import { OrderCancellationService } from './order-cancellation.service'
import { PaymentsHealthJob } from './payments-health.job'
import { PaymentFactApplier } from './facts/payment-fact.applier'
import { ReconciliationService } from './facts/reconciliation.service'
import { PaymentOperationsController } from './payment-operations.controller'

/**
 * Payments: merchant gateway configuration, payment operations,
 * reporting and health monitoring.
 *
 * No gateway adapter talks to a provider yet.
 */
@Module({
  imports: [
    PrismaModule,
    ActiveStoreModule,
    CryptoModule,
    IdsModule,
    LedgerModule,
    MessagingModule,
    GatewaysModule,
  ],
  controllers: [PaymentSettingsController, PaymentOperationsController],
  providers: [
    PaymentAccountService,
    PaymentCollectionService,
    PaymentQueryService,
    OrderCancellationService,
    PaymentsHealthJob,
    PaymentFactApplier,
    ReconciliationService,
    PaymentsHealthJob,
  ],
  exports: [
    GatewaysModule,
    PaymentAccountService,
    PaymentCollectionService,
    PaymentQueryService,
    OrderCancellationService,
    PaymentFactApplier,
    ReconciliationService,
  ],
})
export class PaymentsModule {}
